GridGain Control Center Agent Module
------------------------
GridGain Control Center agent is a GridGain module that allows
Control Center to retrieve metrics from and execute management
operations in a Ignite cluster.
To enable the module, copy the module directory to '{IGNITE_HOME}/libs/' or
add the module's libraries to the classpath of your application.
